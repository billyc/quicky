/*********************************************************************

	Responsive Bootstrap Theme "Extended Basic" 1.0
    Stable Version "Great Pumpkin" | Released 2015.10.31
	
	Jürgen Buchberger <jbuchberger@direktmarketingtool.de>
	Copyright (c) 2015 DMT direktmarketingtool.de GmbH
	http://www.direktmarketingtool.de
	
	Follow us on Facebook in English: https://www.facebook.com/dmtgmbhen
	Folge uns auf Facebook in Deutsch: https://www.facebook.com/dmtgmbh

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

**********************************************************************/

INSTALLATION
1. First make a backup of all core folders and files listed below
index.php
pages/
include/class.format.php
include/class.forms.php
include/class.page.php
include/client/
include/staff/​page.inc.php
include/staff/pages.inc.php​

2. Upload the content of the "upload"-folder in this package to your server
3. Replace all files
4. Have fun

UNINSTALLATION
1. Upload all backup-files to your server replacing the existing
2. Remove the folders listed below
ext_css
ext_font-awesome
ext_fonts
ext_images
ext_js
3. Ready

SUPPORT
If you have any troubles or problems, feel free to contact me:
jbuchberger@direktmarketingtool.de

BUGS & FIXES
Please report your discovered bugs to info@direktmarketingtool.de
We will release a updated version as soon as possible.

FEEDBACK
If you like the theme and our work, please give us some feedback

Facebook in English: https://www.facebook.com/dmtgmbhen
Facebook in Deutsch: https://www.facebook.com/dmtgmbh

CUSTOMIZATION
If you like to have a customized version, contact me:
jbuchberger@direktmarketingtool
We will do it for a affordable charge